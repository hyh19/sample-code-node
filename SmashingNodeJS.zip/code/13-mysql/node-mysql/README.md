
# MySQL

## node-mysql app

For all the steps in this application execute

    npm install

Then execute

    node server

and point your browser to `http://127.0.0.1:3000`. Make sure MySQL is
running!

