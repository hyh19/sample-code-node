
# The module system

## Exposing APIs

The first example demonstrates accessing the API exported by a module.
Run it with

    node index

The second example is an iteration of the first that exhibits a common 
pattern: OO in JavaScript by exporting a constructor as a module. Run it
with

    node index2
