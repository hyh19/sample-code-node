
# Redis

## Test

This example allows you to test the basic Redis client functionality.
Make sure Redis is running, and run (in step-4)

    node test

If you want to repeat the experiment, make sure to clear the Redis 
database. If you want to wipe all data from Redis you can run:

    redis-cli FLUSHALL
