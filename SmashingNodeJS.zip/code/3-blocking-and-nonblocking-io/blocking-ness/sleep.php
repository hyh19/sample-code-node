<?php
print('Hello ');

sleep(5);

print('World');
?>
