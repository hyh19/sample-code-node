
# The Global Object

The first example demonstrates the utility `nextTick` found in the
`process` global.

Run it with

    node next-tick.js
