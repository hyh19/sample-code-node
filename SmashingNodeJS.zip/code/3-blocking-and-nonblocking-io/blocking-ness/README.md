
# Blocking-ness

## PHP example

To run the PHP example execute from the shell:

    $ php sleep.php

Note: make sure you have the PHP cli module installed to run this example
http://www.php.net/manual/en/features.commandline.introduction.php

Run the Node.JS example with:

    $ node timeout.js
