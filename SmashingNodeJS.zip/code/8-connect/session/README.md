
# Connect

## Session

All the examples for this chapter require that you install the module
dependencies from NPM as follows:

    npm install

Then run this example with

    node server

and point your browser to `http://127.0.0.1:3000`. To see what users
and passwords are valid, or to edit them look at `users.json`.
