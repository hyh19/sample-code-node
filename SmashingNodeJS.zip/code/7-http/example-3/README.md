
# HTTP

## Example 3

To run this example simply execute

    node example-3

And point your browser to `http://127.0.0.1:3000`. Notice that the 
HTML codes now work.
