
# Connect

## Logger

All the examples for this chapter require that you install the module
dependencies from NPM as follows:

    npm install

Then run this example with

    node server

and point your browser to `http://127.0.0.1:3000`.

Notice that as you navigate the site, requests will be logged to the
console with the `logger` middleware.
