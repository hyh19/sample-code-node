
# HTTP

## Example 1

To run this example simply execute

    node example-1

And point your browser to `http://127.0.0.1:3000`
