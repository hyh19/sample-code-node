console.log('Hello');

setTimeout(function () {
  console.log('World');
}, 5000);
