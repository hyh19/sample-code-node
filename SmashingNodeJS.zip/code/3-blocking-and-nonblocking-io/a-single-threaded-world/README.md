
# A single-threaded world

Run the example from the shell as follows

    node timeouts.js
