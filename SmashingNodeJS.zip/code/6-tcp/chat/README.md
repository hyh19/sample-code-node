
# TCP

## Chat

To test the chat examples you're going to need the `telnet` command-line
utility.

Go to each step and run

    node index

And then telnet from one or more clients to chat with:

    telnet 127.0.0.1 3000
