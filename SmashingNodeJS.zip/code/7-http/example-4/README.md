
# HTTP

## Example 4

This example is just like Example 3, but in this case we're inspecting
the request object and printing it to the console.

Run it with

    node server

and point your browser to `http://127.0.0.1:3000`.

