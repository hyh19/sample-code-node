
# TCP

## IRC client

To run the IRC example, please first use your favorite desktop client
to join the `#node.js` channel on `irc.freenode.net`.

Some examples include mIRC (Windows), Colloquy (Mac) and X-Chat
(cross-platform).

Then, run the example with

    node index

You will notice your script will have joined the channel! Feel free to
replace "mynick" in the code with your preferred nickname.
