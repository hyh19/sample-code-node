
# Buffers

The example in this directory will produce `logo.gif` image that you
can open with your favorite image viewer. Run it with

    node index

On Mac OS X, you can run the command

    open logo.gif

to open and visualize the image right from your terminal.
