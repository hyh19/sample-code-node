
# The module system

## Absolute and relative modules

The first example you should run will demonstrate the error you get when
you try to access a local (relative) module without including the dot 
(absolute).

Run it as follows

    node main-missing-dot.js

After that, you can run

    node main.js

to see `require` in action!
