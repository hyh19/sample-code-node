
# Events

The first example demonstrates a simple stadalone event emitter:

    node simple-events

The second one shows how you can integrate an `EventEmitter` to any
constructor (through inheritance)

    node oop-events
