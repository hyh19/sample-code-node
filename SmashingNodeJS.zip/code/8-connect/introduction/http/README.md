
# Connect

## HTTP

Run this example with

    node server

and point your browser to `http://127.0.0.1:3000`.
