
module.exports = require('./b')('world');
