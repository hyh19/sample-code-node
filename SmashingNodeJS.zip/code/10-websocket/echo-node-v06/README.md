
# WebSockets

## Echo app

For all the steps in the application you have to run

    npm install

Make sure you're running Node 0.6. If you're running Node 0.8, there's
another directory for the app with the right dependencies.

Then execute

    node server

and point your browser to `http://127.0.0.1:3000`. Make sure your browser
supports WebSockets.
